<? # Скрипт, принимающий все ajax запросы от пользователей
session_start();
Header("Cache-Control: no-cache, must-revalidate"); Header("Pragma: no-cache");
$ajaxflag=1;
@require($_SERVER["DOCUMENT_ROOT"]."/core/projectname.php");
@require_once($_SERVER["DOCUMENT_ROOT"]."/core/system-param.php");#Параметры портала, юзер сеттинги
@require($_SERVER["DOCUMENT_ROOT"]."/core/functions/KLogger.php");
$log->LogInfo("ajaxapi | ------ The new ajax request ------");
foreach ($_POST as $Key => $Value) $comma_separated_req .= $Key . '=' . $Value.";";
$log->LogDebug("ajaxapi | ".(__LINE__)." | REQUEST parameters: ".$comma_separated_req);
include($_SERVER["DOCUMENT_ROOT"]."/core/check_ajax.php"); // Проверяем, ajax ли
include_once $_SERVER["DOCUMENT_ROOT"].'/core/insert_function_function.php';
$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to insert memoryUsage function");
insert_function("memoryUsage");
insert_function("insert_module");
$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to check available modules");
@require($_SERVER["DOCUMENT_ROOT"]."/core/check_avail_modules.php");
$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to get mode from get");
@include_once($_SERVER["DOCUMENT_ROOT"]."/core/modefromget.php");#Определение $mode
if($block!==1){
	//@include_once($_SERVER["DOCUMENT_ROOT"]."/core/functions/process_user_data.php");
	insert_function("process_user_data");
	@require_once($_SERVER["DOCUMENT_ROOT"]."/core/messages.php");#Все сообщения портала
	if($_REQUEST['action']){
		$requestaction=process_data($_REQUEST['action'],50);
		$log->LogInfo("ajaxapi.php | ".(__LINE__)." | Action in request: ".$requestaction);
		}
	if ($_REQUEST['mod']){# Вызов от какого то модуля
		if ($modulename=process_data($_REQUEST['mod'],50)){$log->LogInfo("ajax/index.php | We got modulename in request equal ".$_REQUEST['mod']);;}
		if($modulename=="usersmanagement"){
			$log->LogDebug("ajaxapi.php | ".(__LINE__)." | Trying to call usersmanagement/ajax.php");
			include($_SERVER["DOCUMENT_ROOT"]."/core/usersmanagement/ajax.php");
		}
		elseif($modulename=="adminpanel"){$adminpanel=1;
			$log->LogDebug("ajaxapi.php | ".(__LINE__)." | Trying to call adminpanel-ajaxactions.php");
			include($_SERVER["DOCUMENT_ROOT"]."/adminpanel/adminpanel-ajaxactions.php");
		} elseif($modulename=="project_script"){
			$log->LogDebug("ajaxapi.php | ".(__LINE__)." | Trying to call /project/".$projectname."/scripts/project-ajax.php");
			include($_SERVER["DOCUMENT_ROOT"]."/project/".$projectname."/scripts/project-ajax.php");
		}
		else {
		
			$log->LogDebug("ajaxapi.php | ".(__LINE__)." | Trying to call ".$modulename."/ajax.php");
			include($_SERVER["DOCUMENT_ROOT"]."/modules/".$modulename."/config.php");
			include($_SERVER["DOCUMENT_ROOT"]."/modules/".$modulename."/ajax.php");
		}

	} elseif ($requestaction=="getpage"){# Показываем страничку
		$log->LogDebug("ajaxapi.php | ".(__LINE__)." | Trying to call pagemanage.php");
		include($_SERVER["DOCUMENT_ROOT"]."/core/pagemanage.php");
		}
	elseif ($requestaction=="checklogin")
		{# Пользователь логинится
		$log->LogDebug("ajaxapi.php | ".(__LINE__)." | Trying to check userrole");
		include($_SERVER["DOCUMENT_ROOT"]."/core/checkuserrole.php"); // Определяем userrole
		if($showmessage){$log->LogDebug("ajax/index.php | ".(__LINE__)." | Message has been shown: ".$showmessage);
			echo "<span style='color:".$messagecolor."'>".$showmessage."</span>";
			if ($userrole!=="guest" and $userrole) echo "<br><br><a href='/logout/' onclick='logout();return false;'>Покинуть кабинет</a>";
		}
		if($userrole!=="guest" and $userrole){?><script>
		//$(window).bind("load", function() {
			closelogin();showmenu('cabinet','leftmenutab');changerazdel('cabinet');
		//});

		$(document).ready(function(){closelogin();showmenu('cabinet','leftmenutab');changerazdel('cabinet');
		});</script><? }
		$showmessage="";$messagecolor="";
		/*if ($changepassmust=="2"){?>
			<div id="changepassform"></div>
			<script>$(document).ready(function(){ajaxreq("","","","changepassform","change_password");});</script><?}*/
		}
	elseif($_REQUEST['action']=="logout")
		{//include($_SERVER["DOCUMENT_ROOT"]."/logout/index.php");
		include($_SERVER["DOCUMENT_ROOT"]."/core/usersmanagement/logout.php");
		?><script>$(document).ready(function(){openlogin();showmenu('<?=$defaultmenu?>','leftmenutab');changerazdel('login');});</script><?
		}
	/*elseif($requestaction=="saveusersettings"){# Изменение статуса ЗАДАЧИ (удалить/восстановить
		include($_SERVER["DOCUMENT_ROOT"]."/core/checkuserrole.php"); // Определяем userrole
		include($_SERVER["DOCUMENT_ROOT"]."/change-usersettings.php");
		}*/
	elseif($requestaction=="saveform")
		{include($_SERVER["DOCUMENT_ROOT"]."/core/checkuserrole.php"); // Определяем userrole
			if($_REQUEST['someid']=="create_user"){include($_SERVER["DOCUMENT_ROOT"]."/core/usersmanagement/ajax.php");
			}
		}
	else{echo "Неизвестный тип действия (action unknown)";}
 } else $log->LogFatal("ajaxapi.php | ".(__LINE__)." | The type of request is not ajax. Query was blocked");
 $log->LogDebug("ajaxapi.php | ------ // The end of ajax request ------");?>
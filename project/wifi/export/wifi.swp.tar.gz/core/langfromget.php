<? # Определяет какой язык запрашивает пользователь
$log->LogInfo(basename (__FILE__)." | ".(__LINE__)." | Got ".(__FILE__));
$log->LogDebug(basename (__FILE__)." | MemUsage ".memoryUsage($base_memory_usage));
//include_once($_SERVER["DOCUMENT_ROOT"]."/core/process_user_data.php");
$language=process_data($_REQUEST['lang'],2);
if ($language) {$_SESSION['language']=$language;}
elseif (!$language and $_SESSION['language']) {$language=$_SESSION['language'];}
elseif (!$language and !$_SESSION['language']) {$language=$_SESSION['language']=$default_language;}
else {echo "Не можем определить язык";}

//if (!$language){$language=$default_language;}
//else $_SESSION['language']=$language;
//echo $language;
//echo $_SESSION['language'];
//echo $default_language;
$log->LogDebug(basename (__FILE__)." | MemUsage (after) ".memoryUsage($base_memory_usage));
	?>
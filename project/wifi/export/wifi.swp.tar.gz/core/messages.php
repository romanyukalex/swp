<? 
/*****************************************************************************************************************************
  * Snippet Name : messages           																						 * 
  * Scripted By  : RomanyukAlex		           																				 * 
  * Website      : http://popwebstudio.ru	   																				 * 
  * Email        : admin@popwebstudio.ru  					 														 	     * 
  * License      : License on popwebstudio.ru from autor		 															 *
  * Purpose 	 : Создаёт массив сообщений портала, выгружая данные из БД													 *
  * Using		 : echo $sitemessage[$module_name][$message_code];															 *
  ***************************************************************************************************************************/ 
$log->LogDebug(basename (__FILE__)." | MemUsage ".memoryUsage($base_memory_usage));
require_once($_SERVER["DOCUMENT_ROOT"]."/core/db/dbconn.php");
require_once($_SERVER["DOCUMENT_ROOT"]."/core/system-param.php");
@include_once($_SERVER["DOCUMENT_ROOT"]."/core/langfromget.php");#Определение $language
$messagedatas=mysql_query("SELECT `module_name`,`message_code`,`message_$_SESSION[language]` FROM `$tableprefix-messages` WHERE 1;");
while($messagedata=mysql_fetch_array($messagedatas)){$sitemessage[$messagedata['module_name']][$messagedata['message_code']] = $messagedata['message_'.$_SESSION[language]];}
$log->LogDebug(basename (__FILE__)." | MemUsage (after) ".memoryUsage($base_memory_usage));
?>
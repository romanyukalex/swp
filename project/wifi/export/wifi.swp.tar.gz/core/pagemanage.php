<? # Управление содержанием страницы, вывод данных на основе $page
// Запрос в БД, где поле = $page
// Структура БД: page - запрос,folder= напр. '/html', filename - название скрипта, pagetitle - название пункта текстом(заголовок страницы), secondlevelmenu - yes or no
$log->LogInfo(basename (__FILE__)." | ".(__LINE__)." | Got ".(__FILE__));
$log->LogDebug(basename (__FILE__)." | ".(__LINE__)." | MemUsage ".memoryUsage($base_memory_usage));
@include_once($_SERVER["DOCUMENT_ROOT"]."/core/system-param.php");
@include_once($_SERVER["DOCUMENT_ROOT"]."/core/pagefromget.php");
@include_once($_SERVER["DOCUMENT_ROOT"]."/core/db/dbconn.php");
if(!$pagequeried) {$pagequery=mysql_fetch_array(mysql_query("SELECT * FROM `$tableprefix-pages` WHERE `page` ='$page' LIMIT 0,1;"));}
	// Инклюдим страницу php или html или из БД
if ($pagequery['pagebody_'.$language]){ # Текст страницы существует в БД	
	$log->LogInfo(basename (__FILE__)." | ".(__LINE__)." | Show page $page from DB");
	echo $pagequery['pagebody_'.$language];
	if ($pagequery['script_after_page']){#Вставляем скрипт после странички
		if(substr_count($pagequery['script_after_page'], ';')>0) {
			$scripts_after_page=explode ( ";" ,$pagequery['script_after_page']);
			foreach($scripts_after_page as $script_after_page){
				include($_SERVER["DOCUMENT_ROOT"]."/project/".$projectname."/scripts/".$script_after_page);
			}
		} else include($_SERVER["DOCUMENT_ROOT"]."/project/".$projectname."/scripts/".$pagequery['script_after_page']);
	}
} elseif (!$pagequery['pagebody_'.$language]) {
	if ($pagequery['filename']){
		
		//if ($pagequery['ext'])$scriptpath.="/project/".$projectname.$pagequery[folder].$pagequery[filename].".".$pagequery[ext];
		
		
		if(substr_count($pagequery['folder'],"/adminpanel/")==0 and substr_count($pagequery['folder'],"/core/usersmanagement/")==0) {
			if ($pagequery['ext']) $scriptpath.="/project/".$projectname.$pagequery['folder'].$pagequery['filename'].".".$pagequery['ext'];
			else $scriptpath.="/project/".$projectname.$pagequery[folder].$pagequery[filename];
		} elseif(substr_count($pagequery['folder'],"/adminpanel/")>0) {
			if ($pagequery['ext']) $scriptpath.=$pagequery[folder].$pagequery[filename].".".$pagequery['ext'];
			else $scriptpath.=$pagequery[folder].$pagequery[filename];
		} elseif(substr_count($pagequery['folder'],"/core/usersmanagement/")>0) {
			 $scriptpath.=$pagequery[folder].$pagequery[filename];
		}
	} elseif ($pagequery[module_page]){$scriptpath="/modules/".$pagequery[module_page]."/startscript.php";}
	if (file_exists($_SERVER["DOCUMENT_ROOT"].$scriptpath)){ # Файл страницы существует, можно вставлять
		$log->LogDebug(basename (__FILE__)." | ".(__LINE__)." | Page file is found - $scriptpath");
		if(!$block or $block!==1){
			echo "<!-- Страница ".$page."-->";
			$log->LogInfo(basename (__FILE__)." | ".(__LINE__)." | Show page $page from file");
			include($_SERVER["DOCUMENT_ROOT"].$scriptpath);
			if ($pagequery['script_after_page']){#Вставляем скрипт после странички
				if(substr_count($pagequery['script_after_page'], ';')>0) {
					$scripts_after_page=explode ( ";" ,$pagequery['script_after_page']);
					foreach($scripts_after_page as $script_after_page){
						//echo $script;
						include($_SERVER["DOCUMENT_ROOT"]."/project/".$projectname."/scripts/".$script_after_page);
					}
				} else include($_SERVER["DOCUMENT_ROOT"]."/project/".$projectname."/scripts/".$pagequery['script_after_page']);
			}
		} elseif ($block==1){
			$log->LogInfo(basename (__FILE__)." | ".(__LINE__)." | Page is 404 because page had been blocked");
			@include($_SERVER["DOCUMENT_ROOT"]."/pages/404.php");
		}
	} else { // $scriptpath нет на диске
		$log->LogDebug(basename (__FILE__)." | ".(__LINE__)." | Page file is not found - $scriptpath");
		@include($_SERVER["DOCUMENT_ROOT"]."/pages/404.php");
		echo "<i style='font-size: xx-small'>Error_desc: scriptpath not exists ($scriptpath) for Page=".$pagequery['page']."</i>";
	}
echo "<!--".$scriptpath."-->";
}
?><script>
$(document).ready(function(){
	$("#breadcrumb #pagelink").html("<a href='/?page=<?=$page?>'><?=$pagequery['pagetitle_'.$language]?></a>");
	$("#titleonpage").hide(300,function(){
	$("#titleonpage").html("<?=$pagequery['pagetitle_'.$language]?>").fadeIn(300)});
});</script><?
$log->LogDebug(basename (__FILE__)." | MemUsage (after) ".memoryUsage($base_memory_usage));
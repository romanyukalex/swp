<? /**************************************************************************************************************************
  * Snippet Name : start_platform_scripts           																		 * 
  * Scripted By  : RomanyukAlex		           																				 * 
  * Website      : http://popwebstudio.ru	   																				 * 
  * Email        : admin@popwebstudio.ru  					 														 	     * 
  * License      : License on popwebstudio.ru from autor		 															 *
  * Purpose 	 : Стартует сессию, инклюдит все необходимые проекту скрипты, делаются проверки на $block					 *
  * Insert		 : include_once('start_platform_scripts.php');																 *
  ***************************************************************************************************************************/


$breakthisfile = Explode('/', $_SERVER["SCRIPT_NAME"]);
unset ($breakthisfile[count($breakthisfile)-1]); //Удалили название скрипта
if($breakthisfile[count($breakthisfile)-1]!=="modules")unset ($breakthisfile[count($breakthisfile)-1]); //Мы все еще в глубине файловой системы, удаляем папку с модулем
unset ($breakthisfile[count($breakthisfile)-1]); //Удаляем /modules
$_SERVER["DOCUMENT_ROOT"]=implode('/', $breakthisfile); // Домашняя директория всего сайта


gc_enable();

$projectname=$argv[1]; // Первый параметр при запуске из командной строки - это название проекта

@require_once($_SERVER["DOCUMENT_ROOT"]."/project/".$projectname."/config.php");#Cистемные параметры

@require_once($_SERVER["DOCUMENT_ROOT"]."/core/system-param.php");#Параметры портала, юзер сеттинги
//settype($sessionlifetime,integer);
//ini_set(’session.gc_maxlifetime’, $sessionlifetime*60);

@require($_SERVER["DOCUMENT_ROOT"]."/core/functions/KLogger.php");
$log->LogInfo("start_platform_scripts_cron | ----- The new console call ".$argv[0]." ----------------");

// Простые php функции из папки /core/functions/ вставляем вручную
$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to call insert_function_function.php");
include_once $_SERVER["DOCUMENT_ROOT"].'/core/insert_function_function.php';// Вызов: insert_function("functionname")

$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to insert memoryUsage function");
insert_function("memoryUsage");

$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to insert insert_module function");
insert_function("insert_module");

$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to check available modules");
@require($_SERVER["DOCUMENT_ROOT"]."/core/check_avail_modules.php");
/*
$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to get mode from get");
@include_once($_SERVER["DOCUMENT_ROOT"]."/core/modefromget.php");#Определение $mode


$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to get all site messages from get");
@require_once($_SERVER["DOCUMENT_ROOT"]."/core/messages.php");#Все сообщения портала на языке портала
*/

$log->LogDebug(basename (__FILE__)." | MemUsage (after) ".memoryUsage($base_memory_usage));

?>
<?/***************************************************************************************************************************
  * Snippet Name : check_avail_modules           																			 * 
  * Scripted By  : RomanyukAlex		           																				 * 
  * Website      : http://magicsolutions.ru	   																				 * 
  * Email        : admin@magicsolutions.ru     					 														     * 
  * License      : License on popwebstudio.ru	from autor		 															 *
  * Purpose 	 : Выбирает реестр подключенных модулей																		 *
  * Insert		 : include_once('check_avail_modules.php');																	 *
  ***************************************************************************************************************************/ 
$log->LogInfo(basename (__FILE__)." | Got ".(__FILE__));
$log->LogDebug(basename (__FILE__)." | MemUsage ".memoryUsage($base_memory_usage));
@include_once($_SERVER["DOCUMENT_ROOT"]."/core/db/dbconn.php");
$avmodulesqry=mysql_query("SELECT * FROM `$tableprefix-modulesregister` WHERE 1;");//два поля - modulename и installed
if(mysql_num_rows($avmodulesqry) > '0'){
	$log->LogDebug(basename (__FILE__)." | Data about module received.");
	while($avmodulesresult=mysql_fetch_array($avmodulesqry)){
		$moduleinstalled[$avmodulesresult['modulename']]=$avmodulesresult['installed'];
		$moduleenabled[$avmodulesresult['modulename']]=$avmodulesresult['enabled'];
	}
} else $log->LogError(basename (__FILE__)." | No modules available.");
mysql_data_seek($avmodulesqry, 0);
// Включен модуль: $moduleinstalled['newsblock']=='y'
$log->LogDebug(basename (__FILE__)." | MemUsage (after) ".memoryUsage($base_memory_usage));
?>

<? /**************************************************************************************************************************
  * Snippet Name : start_platform_scripts           																		 * 
  * Scripted By  : RomanyukAlex		           																				 * 
  * Website      : http://popwebstudio.ru	   																				 * 
  * Email        : admin@popwebstudio.ru  					 														 	     * 
  * License      : License on popwebstudio.ru from autor		 															 *
  * Purpose 	 : Стартует сессию, инклюдит все необходимые проекту скрипты, делаются проверки на $block					 *
  * Insert		 : include_once('start_platform_scripts.php');																 *
  ***************************************************************************************************************************/
session_start();
gc_enable();
@require($_SERVER["DOCUMENT_ROOT"]."/core/projectname.php");
@require_once($_SERVER["DOCUMENT_ROOT"]."/project/".$projectname."/config.php");#Cистемные параметры
if($install_swp==1){
	$nitka=1;
	require($_SERVER["DOCUMENT_ROOT"]."/pages/install.php");die();
}

@require_once($_SERVER["DOCUMENT_ROOT"]."/core/system-param.php");#Параметры портала, юзер сеттинги
settype($sessionlifetime,integer);
ini_set(’session.gc_maxlifetime’, $sessionlifetime*60);
@require($_SERVER["DOCUMENT_ROOT"]."/core/functions/KLogger.php");
$log->LogInfo("start_platform_scripts | ----- The new request to ".$_SERVER['HTTP_HOST']." ----------------");

// Простые php функции из папки /core/functions/ вставляем вручную
$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to call insert_function_function.php");
include_once $_SERVER["DOCUMENT_ROOT"].'/core/insert_function_function.php';// Вызов: insert_function("functionname")

$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to insert memoryUsage function");
insert_function("memoryUsage");

$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to insert insert_module function");
insert_function("insert_module");

$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to check available modules");
@require($_SERVER["DOCUMENT_ROOT"]."/core/check_avail_modules.php");

$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to get browser");
@include_once($_SERVER["DOCUMENT_ROOT"]."/core/browser.php");

$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to check if it is bot");
@require($_SERVER["DOCUMENT_ROOT"]."/core/check_bots.php");

$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to found injection");
@require($_SERVER["DOCUMENT_ROOT"]."/core/check_injection.php");
if(!$adminpanel){
	$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to get template from get");
	@include_once($_SERVER["DOCUMENT_ROOT"]."/core/templatefromget.php");#Определение $sitetemplate
}
$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to get page from get");
@include_once($_SERVER["DOCUMENT_ROOT"]."/core/pagefromget.php");#Определение $page

$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to get mode from get");
@include_once($_SERVER["DOCUMENT_ROOT"]."/core/modefromget.php");#Определение $mode

$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to get menu from get");
@include_once($_SERVER["DOCUMENT_ROOT"]."/core/menufromget.php");#Определение $menureq

$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to get language from get");
@include_once($_SERVER["DOCUMENT_ROOT"]."/core/langfromget.php");#Определение $language

$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to get all site messages from get");
@require_once($_SERVER["DOCUMENT_ROOT"]."/core/messages.php");#Все сообщения портала на языке портала


if ($shutdownsite=="НЕ ПОКАЗЫВАТЬ"){
	$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Site shutdowned by admin");
	$block=1;
}
if ($autoincludeclasses=="Включено"){//автозагрузка классов из папки /core/functions/
	$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to call autoload_scripts_from_functions.php");
	@include_once($_SERVER["DOCUMENT_ROOT"]."/core/autoload_scripts_from_functions.php");
}
if ($includeemail=="Включено") {
	$log->LogDebug("start_platform_scripts | ".(__LINE__)." | Trying to insert SEND_LETTER function");
	insert_function("send_letter");
}
$log->LogDebug(basename (__FILE__)." | MemUsage (after) ".memoryUsage($base_memory_usage));
?>
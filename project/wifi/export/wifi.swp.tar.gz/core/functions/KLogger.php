<?php
	/* Finally, A light, permissions-checking logging class. 
	 * 
	 * Author	: Kenneth Katzgrau < katzgrau@gmail.com >
	 * Adapted for SWP: Alexey Romanyuk <admin@popwebstudio.ru>
	 * Date	: July 26, 2008
	 * Comments	: Originally written for use with wpSearch
	 * Website	: http://codefury.net
	 * Version	: 1.0
	 *
	 * Usage: 
	 *		$log = new KLogger ( "log.txt" , KLogger::INFO );
	 *		$log->LogInfo("Returned a million search results");	//Prints to the log file
	 *		$log->LogFATAL("Oh dear.");				//Prints to the log file
	 *		$log->LogDebug("x = 5");					//Prints nothing due to priority setting
	
	 *	DEBUG 	= 1;	// Вся логика подробно. Например, сообщения, выдаваемые пользователю. Все что не перечислено в следующих уровнях, присваиваем debug
	 *
	 *	INFO 	= 2;	// Переход на новый скрипт (в начале каждого скрипта). Тип запроса (ajax или обычный). Данные, присланные пользователем. 
	 *					// Факт удачного входа в систему. Выбранная страница, язык и тп.
	 *
	 *	WARN 	= 3;	// Факт неудачного входа в систему
	 *
	 *	ERROR 	= 4;	// Под error мы пишем ошибки вроде не найденных страниц (404). Неправильные значения переменных, присланных пользователем. 
	 *					// Невозможность отправить оповещение пользователю
	 *
	 *	FATAL 	= 5;	// Под фаталом прописываем самые жестокие ошибки вроде обходов защиты, наличие $block, не найденные части системы и тп
	 *
	*/
	
class KLogger{
	
	const DEBUG 	= 1;	// Most Verbose
	const INFO 		= 2;	// ...
	const WARN 		= 3;	// ...
	const ERROR 	= 4;	// ...
	const FATAL 	= 5;	// Least Verbose
	const OFF 		= 6;	// Nothing at all.
	
	const LOG_OPEN 		= 1;
	const OPEN_FAILED 	= 2;
	const LOG_CLOSED 	= 3;
	
	/* Public members: Not so much of an example of encapsulation, but that's okay. */
	public $Log_Status 	= KLogger::LOG_CLOSED;
	public $DateFormat	= "Y-m-d H:i:s";
	public $MessageQueue;
	
	private $log_file;
	private $priority = KLogger::INFO;
	
	private $file_handle;
	
	private $cust_ip;
	
	public function __construct( $filepath , $priority ){	
		# IP
		include_once($_SERVER["DOCUMENT_ROOT"]."/core/IPreal.php");
		openlog("swp", LOG_PID, LOG_LOCAL0);
		$this->cust_ip=$ip;
		if ( $priority == KLogger::OFF ) return;
		$this->log_file = $filepath;
		$this->MessageQueue = array();
		$this->priority = $priority;
		if ( file_exists( $this->log_file ) )
		{
			if ( !is_writable($this->log_file) )
			{
				$this->Log_Status = KLogger::OPEN_FAILED;
				$this->MessageQueue[] = "The log file exists, but could not be opened for writing. Check that appropriate permissions have been set.";
				print_r($this->MessageQueue);
				return;
			}
		} else echo "Log file does not exist";
		
		if ( $this->file_handle = fopen( $this->log_file , "a" ) ){
			$this->Log_Status = KLogger::LOG_OPEN;
			$this->MessageQueue[] = "The log file was opened successfully.";
		}
		else{
			$this->Log_Status = KLogger::OPEN_FAILED;
			$this->MessageQueue[] = "The log file could not be opened. Check permissions.";
			print_r($this->MessageQueue);
		}
		return;
	}
	
	public function __destruct()
	{
		if ( $this->file_handle )
			fclose( $this->file_handle );
		closelog();
	}
	
	public function LogDebug($line)
	{
		$this->Log( $line , KLogger::DEBUG );
	}
	
	public function LogInfo($line)
	{
		$this->Log( $line , KLogger::INFO );
	}
	
	public function LogWarn($line)
	{
		$this->Log( $line , KLogger::WARN );	
	}
	
	public function LogError($line)
	{
		$this->Log( $line , KLogger::ERROR );		
	}

	public function LogFatal($line)
	{
		$this->Log( $line , KLogger::FATAL );
	}
	
	public function Log($line, $priority)
	{
		if ( $this->priority <= $priority )
		{	# Запись в лог
			global $writelogto;
			global $login;
			if (!$login){$login="guest";}
			switch( $priority )
				{
					case KLogger::DEBUG:
						$loglevtext="DEBUG"; break;
					case KLogger::INFO:
						$loglevtext="INFO "; break;
					case KLogger::WARN:
						$loglevtext="WARN "; break;
					case KLogger::ERROR:
						$loglevtext="ERROR"; break;
					case KLogger::FATAL:
						$loglevtext="FATAL"; break;
					default:
						$loglevtext="LOG   "; break;
				}
			
			if($writelogto=="Собственный лог" or $writelogto=="Собственный и SYSLOG" ){
				$timest = $this->getTimeLine($priority);
				$this->WriteFreeFormLine ( "$timest - $loglevtext--> $this->cust_ip | $login | $line\n" );
			} 
			if($writelogto=="SYSLOG" or $writelogto=="Собственный и SYSLOG" ){
				//$loglev="LOG_".str_replace(" ", "", $loglevtext);
				//echo $loglev;
				syslog(LOG_DEBUG,"$this->cust_ip | $login | $line");
			}
			// Сделать $login в лог
		}
	}
	
	public function WriteFreeFormLine( $line )
	{
		if ( $this->Log_Status == KLogger::LOG_OPEN && $this->priority != KLogger::OFF )
		{
			if (fwrite( $this->file_handle , $line ) === false) {
				$this->MessageQueue[] = "The file could not be written to. Check that appropriate permissions have been set.";
			}
		}
	}
	
	private function getTimeLine()
	{		
		$mtime = microtime(true);
		$time1 = floor($mtime);
		$ms = $mtime - $time1;
		$time = date( $this->DateFormat ).":".substr($ms,2,4);
		return $time;
		/*
		switch( $level )
		{
			case KLogger::DEBUG:
				return "$time - DEBUG";		
			case KLogger::INFO:
				return "$time - INFO ";
			case KLogger::WARN:
				return "$time - WARN ";				
			case KLogger::ERROR:
				return "$time - ERROR";
			case KLogger::FATAL:
				return "$time - FATAL";
			default:
				return "$time - LOG	 ";
		}*/
	}
}

class emptyLogger { # Заглушка, если логи выключены
		
	public function LogDebug($line)
	{
		return TRUE;
	}
	
	public function LogInfo($line)
	{
		return TRUE;
	}
	
	public function LogWarn($line)
	{
		return TRUE;
	}
	
	public function LogError($line)
	{
		return TRUE;
	}

	public function LogFatal($line)
	{
		return TRUE;
	}
}


if ($adminpanel==1) {$ap_loglevel="KLogger::$ap_loglevel";
	$log=new KLogger( $ap_logfile , $ap_loglevel);
} elseif($nitka==1) {
	$loglevel="KLogger::$loglevel";
	$log=new KLogger( $logfile , $loglevel);
}

?>
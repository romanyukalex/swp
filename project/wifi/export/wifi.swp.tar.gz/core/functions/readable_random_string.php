<? # Функция генерации случайных последовательностей в читабельном виде
$log->LogInfo(basename (__FILE__)." | Got ".(__FILE__));

function readable_random_string($length = 8){
    $conso=array("b","c","d","f","g","h","j","k","l",
    "m","n","p","r","s","t","v","w","x","y","z");
    $vocal=array("a","e","i","o","u");
    $password="";
    srand ((double)microtime()*1000000);
    $max = $length/2;
    for($i=1; $i<=$max; $i++)
    {
    $password.=$conso[rand(0,19)];
    $password.=$vocal[rand(0,4)];
    }
	global $log;
    $log->LogDebug(basename (__FILE__)." | readable_random_string result is ".substr($password,0,$length);
    return substr($password,0,$length);
}

<? $log->LogInfo(basename (__FILE__)." | Got ".(__FILE__));
include_once($_SERVER["DOCUMENT_ROOT"]."/core/system-param.php");
function sendletter($to_email_address,$subject,$message)
	{
	global $sitedomainname;
	global $emailaddress;
	global $from;
	sendletter_full($to_email_address,$to_email_address,$subject,$message,$from,$emailaddress);
	}
function sendletter_to_admin($subject,$message){
global $adminemailforspy;
sendletter($adminemailforspy,$subject,$message);
}
function sendletter_full($to_email_name,$to_email_address,$subject,$message,$from_email_name,$from_email_address)
	{
	global $log;
    $log->LogDebug(basename (__FILE__)." | Called '".(__FUNCTION__)."' function with params: ".implode(',',func_get_args()));
	//echo $to_email_name." ".$to_email_address." ".$subject." ".$message." ".$from_email_name." ".$from_email_address;
	global $sitedomainname;
	$header="Content-type: text/html;  charset=\"UTF-8\"\r\n";	
	$header.="From: =?utf-8?B?".base64_encode($from_email_name)."?= <".$from_email_address.">\r\n";
	$header.='Reply-To: noreply@'.$sitedomainname."\r\n";
	$header.="Content-Transfer-Encoding: utf-8\r\n";
	$header.="Content-Disposition: inline\nMIME-Version: 1.0\r\n";
	$header.= "X-Priority: 1 (Highest)\r\n";
	$header.= "X-MSMail-Priority: High\r\n";
#	$headers .= "Importance: High\n";
	@ mail("=?utf-8?B?".base64_encode($to_email_name)."?= <".$to_email_address.">", '=?UTF-8?B?'.base64_encode($subject).'?=', $message, $header);
	}
?>
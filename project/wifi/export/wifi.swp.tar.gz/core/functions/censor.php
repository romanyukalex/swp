<?php 
 /*********************************************** 
  * Snippet Name : censorMsg                    * 
  * Scripted By  : Hermawan Haryanto            * 
  * Website      : http://hermawan.dmonster.com * 
  * Email        : hermawan@dmonster.com        * 
  * License      : GPL (General Public License) * 
  * Access		 : $msg = censorMsg($msg,"*");	*
  ***********************************************/
$log->LogInfo(basename (__FILE__)." | Got ".(__FILE__));

function str_repeats($input, $mult) { 
	$ret = ""; 
	while($mult>0) {
		$ret .= $input; 
		$mult --; 
	} 
	return $ret; 
} 
function censor($msg, $replacement="*"){ 
	global $log;
    $log->LogDebug(basename (__FILE__)." | Called '".(__FUNCTION__)."' function with params: ".implode(',',func_get_args()));
    global $badwordslist; 
    $badwords = explode("|", $bw); 
    $eachword = explode(" ", $msg); 
    for($j=0;$j<count($badwords);$j++){ 
		for($i=0;$i<count($eachword);$i++){
        	//if(is_int(strpos(strtolower($eachword[$i]), $badwords[$j]))) - почемуто не заработало
			if(is_int(strpos(strtr($eachword[$i], "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ", "абвгдеёжзийклмнопрстуфхцчшщъыьэюя"), $badwords[$j]))){ 
				$msg = eregi_replace($eachword[$i],str_repeats($replacement,strlen($eachword[$i])),stripslashes($msg)); 
        	} 
     	} 
    } 
    return $msg; 
}
?>
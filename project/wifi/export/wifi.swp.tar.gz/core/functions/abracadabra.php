<? # Функция генерации случайных последовательностей
$log->LogInfo(basename (__FILE__)." | Got ".(__FILE__));
function abracadabra($strlen,$symbol_mode){ 
	global $log;
	$log->LogDebug(basename (__FILE__)." | Called '".(__FUNCTION__)."' function with params: ".implode(',',func_get_args()));
	
	if($symbol_mode=="digits"){$arr = array('1','2','3','4','5','6','7','8','9','0');}
	elseif($symbol_mode=="characters"){$arr = array('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','r','s','t','u','v',
'x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','R','S','T','U','V',
'X','Y','Z');
	}
	elseif($symbol_mode=="mix"){$arr = array('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','r','s','t','u','v',
'x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','R','S','T','U','V',
'X','Y','Z','1','2','3','4','5','6','7','8','9','0');
	}
	$abracadabra="";
	for($i = 0; $i < $strlen; $i++){$index2 = rand(0, count($arr) - 1);$abracadabra .= $arr[$index2];}
	return $abracadabra;
}
<?php
/*$code = get_html_code_url("popwebstudio.ru"); // Скачиваю код страницы
echo htmlspecialchars($code); // Вывожу на экран*/
function get_html_code_url($url) {
	global $log;
    $log->LogDebug(basename (__FILE__)." | Called '".(__FUNCTION__)."' function with params: ".implode(',',func_get_args()));
    $curl = curl_init(); // Инициализирую CURL
    curl_setopt($curl, CURLOPT_HEADER, 0); // Отключаю в выводе header-ы
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); //Возвратить данные а не показать в браузере
    curl_setopt($curl, CURLOPT_URL, $url); // Указываю URL
    $code = curl_exec($curl); // Получаю данные
    curl_close($curl); // Закрываю CURL сессию
    return $code;
}?>

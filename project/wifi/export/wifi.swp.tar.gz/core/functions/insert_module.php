<?php
$log->LogInfo(basename (__FILE__)." | Got ".(__FILE__));
function insert_module(){
	$numargs = func_num_args();//Колличество аргументов
	$param = func_get_args();//Получили все аргументы
	global $sitemessage,$nitka,$tableprefix,$language,$log,$projectname;
	if($param[0]) {//Определили модуль для подключения
	
	
		# Читаем конфиг модуля
		if (is_readable($_SERVER["DOCUMENT_ROOT"]."/project/".$projectname."/modules_data/".$param[0].".config.php")) {#Конфиг модуля в папке проекта
			$modconfigexist=1;
			include($_SERVER["DOCUMENT_ROOT"]."/project/".$projectname."/modules_data/".$param[0].".config.php");
			$log->LogDebug(basename (__FILE__)." | ".(__LINE__)." | Module config is in /project/".$projectname."/modules_data/");
		} elseif (is_readable($_SERVER["DOCUMENT_ROOT"]."/modules/".$param[0]."/config.php")) {#Конфиг модуля общий
			$modconfigexist=1;
			include($_SERVER["DOCUMENT_ROOT"]."/modules/".$param[0]."/config.php");
			$log->LogDebug(basename (__FILE__)." | ".(__LINE__)." | Module config is in /modules/".$param[0]."/");
		}
		# Требуется ли инсталляция модуля
		global $moduleinstalled,$userrightsreq,$moduleenabled;;
		if($moduleinstalled[$param[0]]!=='y' or !$moduleinstalled[$param[0]]){
			if ($modconfigexist==1){
				install_module("$param[0]");
			}
		}
		if ($moduleenabled[$param[0]]=='enabled'){
			$log->LogDebug(basename (__FILE__)." | ".(__LINE__)." | Trying to include module design file for ".$param[0]);
			if (is_readable($_SERVER["DOCUMENT_ROOT"]."/project/".$projectname."/modules_data/".$param[0].".design.php")){
				
				return include($_SERVER["DOCUMENT_ROOT"]."/project/".$projectname."/modules_data/".$param[0].".design.php");
			} else {
			
			return include($_SERVER["DOCUMENT_ROOT"]."/modules/".$param[0]."/design.php");
			}
		} else {$log->LogDebug(basename (__FILE__)." | ".(__LINE__)." | Module ".$param[0]." is disabled ".(__FILE__));}
	} else {# Пропущено название модуля
		$log->LogError(basename (__FILE__)." | ".(__LINE__)." | Module name has been missed");
		echo $sitemessage["system"]["module_name_missed"];
	}
}
function install_module(){
	//$numargs = func_num_args();//Колличество аргументов
	$param = func_get_args();//Получили все аргументы
	global $sitemessage,$nitka,$tableprefix,$language,$log,$moduleinstalled,$userrightsreq,$projectname;
	if($param[0]) {//Определили модуль для подключения
		# Читаем конфиг модуля
		if (is_readable($_SERVER["DOCUMENT_ROOT"]."/project/".$projectname."/modules_data/".$param[0].".config.php")) {#Конфиг модуля в папке проекта
			$modconfigexist=1;
			include($_SERVER["DOCUMENT_ROOT"]."/project/".$projectname."/modules_data/".$param[0].".config.php");
			$log->LogDebug(basename (__FILE__)." | ".(__LINE__)." | Module config is in /project/".$projectname."/modules_data/");
		} elseif (is_readable($_SERVER["DOCUMENT_ROOT"]."/modules/".$param[0]."/config.php")) {#Конфиг модуля общий
			$modconfigexist=1;
			include($_SERVER["DOCUMENT_ROOT"]."/modules/".$param[0]."/config.php");
			$log->LogDebug(basename (__FILE__)." | ".(__LINE__)." | Module config is in /modules/".$param[0]."/");
		}
		if($modconfigexist){			
			include_once($_SERVER["DOCUMENT_ROOT"]."/core/db/dbconn.php");
			# Ставим метку об инсталляции в реестр модулей
			$modregisterqry=mysql_query("INSERT into `$tableprefix-modulesregister` 
			(`module_id` ,`modulename` ,`moduletype`,`module_description` ,`installed` ,`install_ts` ,`enabled` )VALUES 
			(NULL , '$modulename', '$moduletype', '$module_description', 'y', CURRENT_TIMESTAMP , 'enabled');");
			$module_id=mysql_insert_id();
			# Если есть файл-инсталлятор
			if (is_readable($_SERVER["DOCUMENT_ROOT"]."/modules/".$param[0]."/install_module.php")) {
				include($_SERVER["DOCUMENT_ROOT"]."/modules/".$param[0]."/install_module.php");
			}
			if($module_id and $modregisterqry) {# Сообщаем об успехе инсталляции модуля
				return "<b>".$sitemessage["system"]["module_installed"].": ".$modulename." (".$param[0].")</b><br><br>";
			} else{return "<b style='color=red'>".$sitemessage["system"]["module_not_installed"].": ".$modulename." (".$param[0].")</b><br><br>";}
		} else {return "<b style='color=red'>".$sitemessage["system"]["module_hasnot_config"].": ".$modulename." (".$param[0].")</b><br><br>";}		
	} else { return $sitemessage["system"]["module_name_missed"];//"*Пропущено название модуля";
	}
}
?>
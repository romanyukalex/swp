<?php
$log->LogInfo(basename (__FILE__)." | Got ".(__FILE__));

function image_dominant_color($imagepath){
	$i = imagecreatefromjpeg($imagepath);

	for ($x=0;$x<imagesx($i);$x++) {
		for ($y=0;$y<imagesy($i);$y++) {
			$rgb = imagecolorat($i,$x,$y);
			$r   = ($rgb >> 16) & 0xFF;
			$g   = ($rgb >>  & 0xFF;
			$b   = $rgb & 0xFF;

			$rTotal += $r;
			$gTotal += $g;
			$bTotal += $b;
			$total++;
		}
	}

	$rAverage = round($rTotal/$total);
	$gAverage = round($gTotal/$total);
	$bAverage = round($bTotal/$total);
	global $log;
    $log->LogDebug(basename (__FILE__)." | image_dominant_color is ".$rAverage.";".$gAverage.";".$bAverage);
	return $rAverage.";".$gAverage.";".$bAverage;
}?>
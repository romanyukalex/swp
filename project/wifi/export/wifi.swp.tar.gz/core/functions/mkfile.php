<? # $filename ������ ����� ������������� ���� (���� dirname/filename.ext)
$log->LogInfo(basename (__FILE__)." | Got ".(__FILE__));
function mkfile($filename, $mode = 0777, $contents) {
	global $log;
	$log->LogDebug(basename (__FILE__)." | Called '".(__FUNCTION__)."' function with params: ".implode(',',func_get_args()));
	$dir = preg_replace("/^(.*\/)[^\/]+$/", "\\1", $filename);
	if (!is_dir($dir)) { trigger_error("mkfile() failed, no such directory <strong>{$dir}</strong>, ", E_USER_WARNING); return(false); }
	if (file_exists($filename)) { trigger_error("mkfile() failed (File exists)", E_USER_WARNING); return(false); }
	if (is_array($contents)) $contents = implode("\n", $contents);
	if ($fp = fopen($filename, "w")) {
		if (is_null($contents)) {
			return($fp);
		} else {
			fwrite($fp, $contents);
			chmod($filename, $mode);
			fclose($fp);
			$log->LogDebug(basename (__FILE__)." | File had been created");
			return TRUE;
		}
	} else {
		trigger_error("mkfile() failed (Wrong file permissions)", E_USER_WARNING);
		$log->LogDebug(basename (__FILE__)." | File had NOT been created");
		return FALSE;
	}
}
?>
<?php
 /***********************************************************
  * Snippet Name : file_force_download	           			* 
  * Scripted By  : RomanyukAlex		           				* 
  * Website      : http://popwebstudio.ru	   				* 
  * Email        : admin@popwebstudio.ru     				* 
  * License      : GPL (General Public License)				* 
  * Purpose 	 : Принудительная скачка файла		 		*
  * Access		 : $response = isSiteAvailable($someUrl); 	*
  **********************************************************/
$log->LogInfo(basename (__FILE__)." | Got ".(__FILE__));
function file_force_download($file){
	global $log;
    $log->LogDebug(basename (__FILE__)." | Called '".(__FUNCTION__)."' function with params: ".implode(',',func_get_args()));
    if ((isset($file))&&(file_exists($file))) {
       header("Content-length: ".filesize($file));
       header('Content-Type: application/octet-stream');
       header('Content-Disposition: attachment; filename="' . $file . '"');
       readfile("$file");
    } else echo "No file selected";
}?>
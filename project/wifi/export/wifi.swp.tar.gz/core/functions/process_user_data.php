<? # Функция обрабатывает $various по стандартным правилам безопасности
$log->LogInfo(basename (__FILE__)." | Got ".(__FILE__));
function process_data($various,$maxletter){ 
$returnvar=htmlspecialchars(substr(trim($various),0,$maxletter), ENT_QUOTES);
return $returnvar;
}
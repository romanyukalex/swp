<? $log->LogInfo(basename (__FILE__)." | Got platform_header");
$log->LogDebug(basename (__FILE__)." | MemUsage ".memoryUsage($base_memory_usage));
?>
<!-- Platform scripts-->
<meta http-equiv="content-type" content="text/html; charset=utf-8;charset=utf-8" />
<META NAME="Keywords" CONTENT="<?
if($page and $pagequery['SEO-keywds_'.$language]) echo $pagequery['SEO-keywds_'.$language];
else echo $keywords;?>">
<META NAME="URL" CONTENT="<?=$_SERVER['SERVER_NAME']; ?>">
<META NAME="Author" CONTENT="<?=$autormeta?>">
<META name="copyright" content="<?=$meta_copyright;?>">
<META NAME="Description" CONTENT="<?if($page and $pagequery['SEO-descrtn_'.$language]) echo $pagequery['SEO-descrtn_'.$language]; else echo $description; ?>" />
<META HTTP-EQUIV="expires" CONTENT="<?=date("D, d M Y H:i:s");?> GMT">
<META NAME="Document-state" CONTENT="Dinamic">
<META NAME="Resource-type" CONTENT="document">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?if($page and $pagequery['SEO-title_'.$language]) echo $pagequery['SEO-title_'.$language];else {if($adminpanel)echo "Администраторская панель ".$sitedomainname;else echo $title;}?></title>
<? insert_module("rss");
# link с языком
if(function_exists('mb_strlen')) $urilenght=mb_strlen($_SERVER['REQUEST_URI']);
else $urilenght=strlen($_SERVER['REQUEST_URI']);
if($language=="ru"){?>
<link title="English" type="text/html" rel="alternate" hreflang="en" href="<?
	$langjustchanged=strpos($_SERVER['REQUEST_URI'],"lang=");
	if($langjustchanged!== false){ // Только сменили язык на русский
		if ($urilenght==9){// Содержится только переменная lang
			echo "/?lang=en";
		}
		else {// Только сменили язык, были не в корне сайта
			echo substr($_SERVER['REQUEST_URI'],0,-8)."&lang=en";
		}
	}
	else { // Просто ходят, не меняли только что язык
		if($_SERVER['REQUEST_URI']!=="/") echo $_SERVER['REQUEST_URI']."&lang=en";
		else echo "/?lang=en";						
	}?>" lang="en" xml:lang="en" /><META http-equiv="content-language" content="ru">
<? } 
else{// Язык страницы английский?>
	<link title="Русский" type="text/html" rel="alternate" hreflang="ru" href="<?
	$langjustchanged=strpos($_SERVER['REQUEST_URI'],"lang=");
	if($langjustchanged!== false){ // Только сменили язык на русский
		
		
		if ($urilenght==9){// Содержится только переменная lang
			echo "/?lang=ru";
		}
		else {// Только сменили язык, были не в корне сайта
			echo substr($_SERVER['REQUEST_URI'],0,-8)."&lang=ru";
		}
	}
	else { // Просто ходят, не меняли только что язык
		if($_SERVER['REQUEST_URI']!=="/") echo $_SERVER['REQUEST_URI']."&lang=ru";
		else echo "/?lang=ru";						
	}?>" lang="ru" xml:lang="ru" /><META http-equiv="content-language" content="en"/>
<?}?>
<link type="image/x-icon" rel="shortcut icon" href='<?=$favicon_shortcut_path?>'/>

<link rel="stylesheet" type="text/css" media="all" href="/style/style.php<?if($adminpanel){?>?adminpanel=1<?}?>" />
<!-- standart project scripts and styles -->
<? # JQuery
if ($takejquery=="Ссылка на сервер Google"){?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<? } elseif($takejquery=="Ссылка на портал JQuery"){?>
<script src="http://code.jquery.com/jquery.min.js"></script>
<? }elseif($takejquery=="Локальный файл /js/lib/jquery/jquery.min.js"){?>
<script src="/js/lib/jquery/jquery.min.js"></script>
<? }
# JQuery-UI
if ($takejqueryui=="Ссылка на сервер Google"){?>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1/jquery-ui.min.js"></script>
<link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/themes/smoothness/jquery-ui.css" />
<? } elseif($takejqueryui=="Ссылка на портал JQuery"){?>
<script src="http://code.jquery.com/ui/1.10.4/jquery-ui.min.js"></script>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.4/themes/black-tie/jquery-ui.css"  type="text/css"/>
<? }elseif($takejqueryui=="Локальные файлы в /js/lib/jquery-ui/"){?>
<script src="/js/lib/jquery-ui/jquery-ui.min.js"></script>
<link rel="stylesheet" href="/js/lib/jquery-ui/jquery-ui.css"  type="text/css"/>
<? }
if($takejqueryui!=="Не вставлять"){?><script>$(function() {$( document ).tooltip();});</script><? }//Активируем jquery-ui
# JQueryMobile
if ($takejquerymob=="Ссылка на сервер Google"){?>
<script src="http://ajax.googleapis.com/ajax/libs/jquerymobile/1.4.2/jquery.mobile.min.js"></script>
<link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jquerymobile/1.4.2/jquery.mobile.css" />
<? } elseif($takejquerymob=="Ссылка на портал JQuery"){?>
<script src="http://code.jquery.com/mobile/1.4.2/jquery.mobile-1.4.2.min.js"></script>
<link rel="stylesheet" href="http://code.jquery.com/mobile/1.4.2/jquery.mobile-1.4.2.min.css"  type="text/css"/>
<? }elseif($takejquerymob=="Локальные файлы в /js/lib/jquery-mob/"){?>
<script src="/js/lib/jquery-mob/jquery.mobile.min.js"></script>
<link rel="stylesheet" href="/js/lib/jquery-mob/jquery.mobile.css"  type="text/css"/>
<? }

if($showtexturlclickable=="Сделать"){?>
<script type="text/javascript" src="/js/text-url-are-clickable.js"></script>
<? }
if($click_eq_msdown=="Включить" and $adminpanel!==1){?><script>document.onmousedown = function(e){e.target.click();}</script><?}
if($enableuserroles=="Включено"){?><script type="text/javascript" src="/js/md5.js"></script><? }
if($enablegooglecount!=="Не включать") insert_module("counter-googleanalytics");
insert_module("counter-liveinternet"); 
insert_module("counter-yandex"); ?>
<script type="text/javascript" src="/js/platformscripts.js"></script>
<!-- // Platform scripts-->
<? $log->LogDebug(basename (__FILE__)." | MemUsage (after) ".memoryUsage($base_memory_usage));?>
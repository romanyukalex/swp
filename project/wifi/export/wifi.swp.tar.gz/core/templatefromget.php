<? # Определяет какой шаблон сайта запрашивает пользователь
$log->LogInfo(basename (__FILE__)." | Got ".(__FILE__));
$log->LogDebug(basename (__FILE__)." | MemUsage ".memoryUsage($base_memory_usage));
include_once($_SERVER["DOCUMENT_ROOT"]."/process_user_data.php");
unset ($sitetemplate);
unset($_SESSION['template']);
if ($_SESSION['template'] and !$_REQUEST['template']) {
	$sitetemplate=$_SESSION['template'];
	$log->LogDebug(basename (__FILE__)." | ".(__LINE__)." | Sitetemplate is from $ SESSION");
} elseif ($_REQUEST['template'] and $ch_template=="Разрешить"){
	$sitetemplate=process_data($_REQUEST['template'],20);
	$_SESSION['template']=$sitetemplate;
	$log->LogDebug(basename (__FILE__)." | ".(__LINE__)." | Sitetemplate is from $ REQUEST");
} else {
	//if($moduleinstalled['templates_manager']=="y"){ # На выходе $
		$log->LogDebug(basename (__FILE__)." | ".(__LINE__)." | Template manager is installed");
		$sitetemplate_q=insert_module("templates_manager");
		if($sitetemplate_q=="notemplate") {//не найден в БД или off
			$log->LogDebug(basename (__FILE__)." | ".(__LINE__)." | Sitetemplate has not found in template_manager");
			$sitetemplate=$currenttemplate;
		} else{# Выдали данные о темплейте в массив
			$log->LogDebug(basename (__FILE__)." | ".(__LINE__)." | Sitetemplate has found in template_manager");
			$sitetemplate=$sitetemplate_q[0];
			$templatepage=$sitetemplate_q[1];
		}
	/*} else {$log->LogDebug(basename (__FILE__)." | ".(__LINE__)." | Template manager is not installed yet");
		insert_module("template_manager");
		$sitetemplate=$currenttemplate;
	}*/
	$_SESSION['template']=$sitetemplate;
	$_SESSION['templatepage']=$templatepage;
}
$log->LogDebug(basename (__FILE__)." | ".(__LINE__)." | Sitetemplate is ".$sitetemplate);
if($templatepage){$log->LogDebug(basename (__FILE__)." | ".(__LINE__)." | Template page is ".$templatepage);}
if(!$sitetemplate){echo $sitemessage["system"]["template_has_no_found"];}
if(!is_readable($_SERVER["DOCUMENT_ROOT"]."/project/".$projectname."/templates/".$sitetemplate."/body.php")){echo $sitemessage["system"]["template_body_has_no_found"];}
if(!is_readable($_SERVER["DOCUMENT_ROOT"]."/project/".$projectname."/templates/".$sitetemplate."/doctype.php")){echo $sitemessage["system"]["template_doctype_has_no_found"];}
if(!is_readable($_SERVER["DOCUMENT_ROOT"]."/project/".$projectname."/templates/".$sitetemplate."/scripts_and_styles.php")){echo $sitemessage["system"]["template_scripts_has_no_found"];}
$log->LogDebug(basename (__FILE__)." | MemUsage (after) ".memoryUsage($base_memory_usage));
?>
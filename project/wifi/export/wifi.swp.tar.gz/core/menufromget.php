<? 
$log->LogInfo(basename (__FILE__)." | Got ".(__FILE__));
$log->LogDebug(basename (__FILE__)." | MemUsage ".memoryUsage($base_memory_usage));
# Определяем $menureq из GET
if($_REQUEST['menu']){$menureq=process_data($_REQUEST['menu'],20);}
elseif($pageshtrihquery['page_menu']){$menureq=$pageshtrihquery['page_menu'];}
else $menureq=NULL;
$log->LogDebug(basename (__FILE__)." | MemUsage (after) ".memoryUsage($base_memory_usage));?>
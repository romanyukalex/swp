<? // Проверка листа популярных ботов
$log->LogInfo(basename (__FILE__)." | Got ".(__FILE__));
$log->LogDebug(basename (__FILE__)." | MemUsage ".memoryUsage($base_memory_usage));
$bot_browser = array ("Wget", "EmailSiphon", "WebZIP","MSProxy/2.0","EmailWolf","webbandit","MS FrontPage");
$se_bot_browser=array ("Yandex","Googlebot","Slurp","Yahoo! Slurp","MSNBot","ia_archiver");
$punish = 0;$se_bot_shows=0;
while (list ($key, $val) = each ($bot_browser)) 
	{if (strstr ($HTTP_USER_AGENT, $val)){$punish = 1;}
	}
while (list ($key, $val) = each ($se_bot_browser)){if (strstr ($HTTP_USER_AGENT, $val)) $se_bot_shows = 1;}
if ($punish==1 or $se_bot_shows==1) {
	// Email the webmaster
	$msg .= "The following session generated banned browser agent errors:n";
	$msg .= "Host: $REMOTE_ADDRn";
	$msg .= "Agent: $HTTP_USER_AGENTn";
	$msg .= "Referrer: $HTTP_REFERERn";
	$msg .= "Document: $SERVER_NAME" . $REQUEST_URI . "n";
	insert__function("send_letter");
	if ($se_bot_shows==1){
		$log->LogInfo(basename (__FILE__)." | Search Engine BOT detected on $sitedomainname $msg");
		sendletter_to_admin("Search Engine BOT detected on ".$sitedomainname,$msg);
	}
	if ($punish==1){
		$log->LogWarn(basename (__FILE__)." | BOT detected on $sitedomainname $msg");
		sendletter_to_admin("BOT detected on ".$sitedomainname,$msg);$block=1; // блокируем показ страницы
	}
}
$log->LogDebug(basename (__FILE__)." | MemUsage (after) ".memoryUsage($base_memory_usage));
?>
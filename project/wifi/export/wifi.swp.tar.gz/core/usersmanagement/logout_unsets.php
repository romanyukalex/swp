<?php # Уничтожает переменные сессии
# Разрегистрируем переменные
//$log->LogInfo(basename (__FILE__)." | Got ".(__FILE__));
unset($_SESSION['login']);
unset($_SESSION['password']);
unset($_SESSION['log']);
unset($_SESSION['userrole']);
unset($_SESSION['nickname']);
unset($_SESSION['company_id']);
unset($_SESSION['fullname']);
unset($_SESSION['changepassmust']);?>
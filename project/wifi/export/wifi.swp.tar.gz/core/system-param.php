<? # Создаёт переменные для сайта, выгружая данные о них из БД
require_once($_SERVER["DOCUMENT_ROOT"]."/core/db/dbconn.php");
$paramdatas=mysql_query("SELECT `value`,`systemparamname` FROM `$tableprefix-siteconfig` WHERE 1;");
while($paramdata=mysql_fetch_array($paramdatas)){$$paramdata['systemparamname'] = $paramdata['value'];}
?>
<?
// Проверим url на иньекции
$log->LogInfo(basename (__FILE__)." | Got ".(__FILE__));
$log->LogDebug(basename (__FILE__)." | MemUsage ".memoryUsage($base_memory_usage));
$req  =  $_SERVER['REQUEST_URI'];
$cadena = explode("?", $req);
$inyecc='/script|http|<|>|%3c|%3e|SELECT|UNION|UPDATE|exe|exec|INSERT|tmp/i'; 
if (preg_match($inyecc, $cadena[1] )){
	$log->LogError(basename (__FILE__)." | Attack injection in \"$req\" from: $ip");
	// make something, in example send an e-mail alert to administrator
	$message = "Attack injection in $req
	from: $ip
	--------- end --------------------";
	//mail("$commentsmail", "Attack injection", $message,"From: host@{$_SERVER['SERVER_NAME']}", "-fwebmaster@{$_SERVER['SERVER_NAME']}");
	insert__function("send_letter");
	sendletter_to_admin("Attack injection ".$sitedomainname,$message);
	$block=1;
	}
$log->LogDebug(basename (__FILE__)." | MemUsage (after) ".memoryUsage($base_memory_usage));
?>
<? 
$log->LogInfo(basename (__FILE__)." | Got ".(__FILE__));
$log->LogDebug(basename (__FILE__)." | MemUsage ".memoryUsage($base_memory_usage));
require_once($_SERVER["DOCUMENT_ROOT"]."/core/IPreal.php");
require_once($_SERVER["DOCUMENT_ROOT"]."/core/functions/IPinRange.php");
if(ipinrange ($valid_ip_address,$ip)==false){$block=1;} 
$log->LogDebug(basename (__FILE__)." | MemUsage (after) ".memoryUsage($base_memory_usage));
?>
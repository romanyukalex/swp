<?		
	require_once($_SERVER["DOCUMENT_ROOT"]."/adminpanel/pages/user_management/class.user.php");
	
	$user = new User();
	if (isset($_REQUEST[userid])) {
		$user->get($_REQUEST[userid]);
	}
	echo "<pre>";print_r($user);echo "</pre>";
	
	$userRole = new UserRole($user->fieldValue("user_role"));
	echo "<pre>";print_r($userRole);echo "</pre>";
	
	$gender = new Gender($user->fieldValue("gender"));
	echo "<pre>";print_r($gender);echo "</pre>";
	
	$company = new Company();
	$company->get($user->fieldValue("company"));
	echo "<pre>";print_r($company);echo "</pre>";
	
	$country = new Country();
	$country->get($user->fieldValue("country"));
	echo "<pre>";print_r($country);echo "</pre>";	
		
	/*@include_once($_SERVER["DOCUMENT_ROOT"]."/core/db/dbconn.php");
	
	class UsersManagementUser {
		
		public function listUserRole() {
			return array(
				"superuser" => array("display"=>"Суперпользователь"),
				"user" => array("display"=>"Пользователь")
			);
		}
		
		public function listGender() {
			return array(
				"male" => array("display"=>"Мужской"),
				"female" => array("display"=>"Женский")
			);
		}
		
		public function listCompany() {
			$result = array();
			$query_companies = mysql_query("SELECT company_id, company_full_name FROM `sc-companies`");
			while ($data = mysql_fetch_array($query_companies)) {
				$result[$data[company_id]] = array("display"=>$data[company_full_name]);
			}
			return $result;
		}
		
		public function listCountry() {
			$result = array();
			$query_countries = mysql_query("SELECT id, country_name_ru FROM `tscloud-country` ORDER BY country_name_ru ASC");
			while ($data = mysql_fetch_array($query_countries)) {
				$result[$data[id]] = array("display"=>$data[country_name_ru]);
			}
			return $result;
		}
		
		public function listRegion($country_id = 219) {
			$result = array();
			$query_regions = mysql_query("SELECT id, region_name_ru FROM `tscloud-region` WHERE id_country='$country_id' ORDER BY region_name_ru ASC");
			while ($data = mysql_fetch_array($query_regions)) {
				$result[$data[id]] = array("display"=>$data[region_name_ru]);
			}
			return $result;
		}
		
		public function listCity($country_id = 219, $region_id = 1611) {
			$result = array();
			$query_cities = mysql_query("SELECT id, city_name_ru FROM `tscloud-cities` WHERE id_country='$country_id' and id_region='$region_id' ORDER BY city_name_ru ASC");
			while ($data = mysql_fetch_array($query_cities)) {
				$result[$data[id]] = array("display"=>$data[city_name_ru]);
			}
			return $result;
		}		
	};
	$handler = new UsersManagementUser();	
	
	$fields = array(
		"login" => array("display"=>"Логин","db"=>"login","type"=>"text"),
		"password" => array("display"=>"Пароль","db"=>"password","type"=>"password"),
		"user_role" => array("display"=>"Роль на сайте","db"=>"userrole","type"=>"select","source"=>"listUserRole","default"=>"superuser"),
		"full_name" => array("display"=>"Полное имя","db"=>"fullname","type"=>"text"),
		"second_name" => array("display"=>"Фамилия","db"=>"second_name","type"=>"text"),
		"first_name" => array("display"=>"Имя","db"=>"first_name","type"=>"text"),
		"patronymic_name" => array("display"=>"Отчество","db"=>"patronymic_name","type"=>"text"),
		"gender" => array("display"=>"Пол","db"=>"gender","type"=>"select","source"=>"listGender","default"=>"male"),
		"birthdate" => array("display"=>"Дата рождения","db"=>"birthdate","type"=>"text"),
		"company" => array("display"=>"Компания","db"=>"company_id","type"=>"select","source"=>"listCompany"),
		"contact_mail" => array("display"=>"Контактная почта","db"=>"contactmail","type"=>"text"),
		"contact_phone" => array("display"=>"Контактный телефон","db"=>"contact_phone","type"=>"text"),
		"country" => array("display"=>"Страна","db"=>"country_id","type"=>"select","source"=>"listCountry","default"=>219),
		"city" => array("display"=>"Город","db"=>"city_id","type"=>"select","source"=>"listCity","default"=>17849),
		"region" => array("display"=>"Регион","db"=>"region_id","type"=>"select","source"=>"listRegion","default"=>1611),
		"address" => array("display"=>"Адрес","db"=>"address","type"=>"text"),
		"status" => array("display"=>"Статус","db"=>"status","type"=>"label"),
		"created_at" => array("display"=>"Создан","db"=>"timestamp","type"=>"label")
	);	
	$fields_groups = array(
		"access"  => array("display"=>"Доступ","members"=>array("login","password","user_role")),
		"person"  => array("display"=>"Личные данные","members"=>array("full_name","gender","birthdate")),
		"contact" => array("display"=>"Контактные данные","members"=>array("company","contact_mail","contact_phone","country","region","city","address")),
		"system"  => array("display"=>"Системные данные","members"=>array("status","created_at"))
	);
	$fields_groups_order = array("system","access","person","contact");
	
	$userid = 0;
	if (isset($_REQUEST[userid])) {
		$userid = $_REQUEST[userid];
	}
	
	$user = array();
	foreach ($fields_order as $field) {
		if (array_key_exists("default",$fields[$field])) {
			$user[$field] = $fields[$field]["default"];
		}
		else {
			$user[$field] = "";
		}
	}
	$query_user = mysql_query("SELECT * FROM `tscloud-users` WHERE userid = '$userid'");
	if ($data = mysql_fetch_array($query_user)) {
		foreach ($fields_order as $field) {
			if ($data[$fields[$field]["db"]] != "") {
				$user[$field] = $data[$fields[$field]["db"]];
			}
		}
	}
?>

<?
	/*foreach($fields_groups_order as $group) {
?>
		<fieldset>
			<label><b><?=$fields_groups[$group][display]?></b></label>
			<table>
				<tr>
					<th width="200px"></th>
					<th></th>
				</tr>
<?
		foreach($fields_groups[$group][members] as $field) {
?>
				<tr>
					<td style="text-align: right;"><?=$fields[$field]["display"]?>
					<td></td>
				</tr>
<?			
		}
?>
			</table>
		</fieldset>
<?
	}*/
?>

<!--	<p style="text-align:center"><a>Удалить пользователя</a></p> -->

<? 
/*****************************************************************************************************************************
  * Snippet Name : adminpanel:users-management.php																					 * 
  * Scripted By  : RomanyukAlex		           																				 * 
  * Website      : http://popwebstudio.ru	   																				 * 
  * Email        : admin@popwebstudio.ru    					 														     * 
  * License      : License on popwebstudio.ru	from autor		 															 *
  * Purpose 	 : 											 					 *
  * Insert		 : 		ПЕРЕДЕЛАТЬ, чтобы такая разметка с левым меню была везде на сайте												 *
  ***************************************************************************************************************************/ 
if($adminpanel==1) {
	if($userrole=="admin" or $userrole=="root") {
		@include_once($_SERVER["DOCUMENT_ROOT"]."/core/db/dbconn.php");
		
		//$query_groups = mysql_query("SELECT group_id, groupname, onoff FROM `$tableprefix-users-groups` WHERE 1 ORDER BY `group_id` ASC"); 

		
?>
		<div id="messages"></div>
		<div id="users_management_container" style="border-left: 250px solid white; background: white;">
			<div id="users_management_menu" style="width: 250px; float: left; margin-left: -250px;">
				<table style="border: 0; text-align: left;">
					<tr><th style="border-bottom: 2px solid black;">Пользователи</th></tr>
					<tr><td><a id="users_management_users_button" class="users-management-menu-button">Управление пользователями</a></td></tr>
					<tr><td><a id="users_management_company_button" class="users-management-menu-button">Управление компаниями</a></td></tr>
					<tr><th style="border-bottom: 2px solid black;">Группы</th></tr>
					<tr><td><a id="users_management_groups_button" class="users-management-menu-button">Управление группами</a></td></tr>
					<tr><td><a id="users_management_groups_right_button" class="users-management-menu-button">Права групп</a></td></tr>
					<tr><td><a id="users_management_groups_member_button" class="users-management-menu-button button1">Участники групп</a></td></tr>
					
				</table>
			</div>
			<div id="users_management_content"></div>
			<div style="clear: both;"></div>
		</div>
<?	}
}
?>
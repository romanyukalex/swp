<? 
/*****************************************************************************************************************************
  * Snippet Name : adminpanel-settings.php																					 * 
  * Scripted By  : RomanyukAlex		           																				 * 
  * Website      : http://popwebstudio.ru	   																				 * 
  * Email        : admin@popwebstudio.ru    					 														     * 
  * License      : License on popwebstudio.ru	from autor		 															 *
  * Purpose 	 : Скрипт обработки изменений настроек сайта											 					 *
  * Insert		 : include_once('Adminpanel-siteconfig_Creator.php');														 *
  ***************************************************************************************************************************/ 
if($adminpanel==1){
if($userrole=="admin" or $userrole=="root"){?>
	<a onClick="showHideSelectionSoft('messagestable',1000)" id="messagestablelink">
		<img src="/adminpanel/pics/NotificationTemplates256.png"  height="64px" class="imgmiddle">Системные сообщения
	</a>
	<div style='display: none;' id='messagestable'>
	<br>
	<? include($_SERVER["DOCUMENT_ROOT"]."/adminpanel/adminpanel-messages.php");?><br><br><br>
	</div><br><br><br>
	
	<? if($userrole=="root"){?>
	<a onClick="showHideSelectionSoft('addnewparam',1000)" id="addnewparamlink">
		<img src="/adminpanel/pics/green-add-circle.png" height="64px" class="imgmiddle">Добавить новый параметр
	</a>
	<div style='display: none;' id='addnewparam'>
	<br>
	<? include($_SERVER["DOCUMENT_ROOT"]."/adminpanel/adminpanel-siteconfig_creator.php");?><br><br><br>
	</div><br><br><br>
	<? }?>
	
	<a onClick="showHideSelectionSoft('settingstablediv',1000)" id="settingstabledivlink">
		<img src="/adminpanel/pics/checklist256.png" height="64px" class="imgmiddle">Параметры системы
	</a>
	<div style='display: none;' id='settingstablediv'>
	<br>
	<? include($_SERVER["DOCUMENT_ROOT"]."/adminpanel/adminpanel-siteconfig.php");?><br><br><br>
	</div><br><br><br>

	<? if($userrole=="root"){?>
	<a onClick="showHideSelectionSoft('exportsiteblock',1000)" id="exportsiteblocklink">
		<img src="/adminpanel/pics/backup-restore256.png" height="64px" class="imgmiddle">Экспорт системы на другой сервер
	</a>
	<div style='display: none;' id='exportsiteblock'>
	<br><br>
	
	<a onclick="ajaxreq('','','export_db','export_ap','adminpanel')" id="dbexportlink" style="margin-left:100px">
		<img src="/adminpanel/pics/Extract-object256.png" height="48px" class="imgmiddle">Экспорт базы данных
	</a><br>
	<div id="export_ap"></div>
	<a onClick="ajaxreq('','','export_code','code_export_ap','adminpanel')" id="savecodelink" style="margin-left:100px">
		<img src="/adminpanel/pics/Save256.png" height="48px" class="imgmiddle">Экспорт кода платформы
	</a>
	<div id="code_export_ap"></div>
	</div>
	<? }?>
<?}?>
<script type="text/javascript" src="js/ColorPicker2/farbtastic.js"></script>
<link rel="stylesheet" href="js/ColorPicker2/farbtastic.css" type="text/css"/>
<? }//Нитка adminpanel?>
<? 
/*****************************************************************************************************************************
  * Snippet Name : adminpanel:users-management.php																					 * 
  * Scripted By  : RomanyukAlex		           																				 * 
  * Website      : http://popwebstudio.ru	   																				 * 
  * Email        : admin@popwebstudio.ru    					 														     * 
  * License      : License on popwebstudio.ru	from autor		 															 *
  * Purpose 	 : 											 					 *
  * Insert		 : 														 *
  ***************************************************************************************************************************/ 

if(($userrole=="admin" or $userrole=="root") and $adminpanel==1){?>
		<h3><img src="pics/html.png" style="vertical-align:middle;">Все страницы сайта</h3>
	<? # Табличка со страницами ?>
		<div id="messages"></div>
		<div id="pages_management_container" style="border-left: 250px solid white; background: white;">
		<table id="pagestable" align="center" class="zebra">
		<tr><th>Название</th><th>URL(?page=)</th><th>Источник</th><th>Действия</th></tr><?
	@include_once($_SERVER["DOCUMENT_ROOT"]."/core/db/dbconn.php");
	$pagequery=mysql_query("SELECT * FROM `$tableprefix-pages` WHERE 1 ;");
	while($pagedata=mysql_fetch_array($pagequery)){
		?>
		<tr id="<?=$pagedata[page]?>_raw">
		<td><?=$pagedata[pagetitle_ru]?></td>
		<td><?=$pagedata[page]?></td>
		<td><?=$pagedata[folder]?><?echo $pagedata[filename]?></td>
		<td class="actionstd"><? if($userrole=="admin" or $pagedata[canbechanged]=="1"){?><a id="<?=$pagedata[page]?>" class="admindeletelink" title="Удалить страницу '<?=$pagedata[pagetitle_ru]?>'"><img src="/files/simplicio/button_cancel.png" border="0"></a>
       <a onClick="editpage('<?=$pagedata[page]?>_raw');return false;" title="Правка страницы '<?=$pagedata[pagetitle_ru]?>'"><img src="/files/simplicio/file_edit.png" border="0"></a><? }?></td>
		</tr>
		<?
		}?>
		<tr id="newpageform" style="display:none;">
			<td><input name="newpagetitle" value="" id="newpagetitle"></td>
			<td><input name="newpagepage" value="" id="newpagepage"></td>
			<td><select name="newpagefolder" id="newpagefolder"><option value="1">/page</option><option value="2">/</option></select></td>
			<td><input name="newpagefilenameext" value="" id="newpagefilenameext"></td>
			<td><a href="#" onClick="createpage();return false;"><img src="/adminpanel/pics/Save-as256.png" width="32"></a></td>
		</tr>
	</table>
	</div>
	<a class="menulink" style="margin-left:18;" onClick="showHideTr('newpageform');" ><img src="/adminpanel/pics/blue-newpage.png" class="smallimg">Создать страницу</a><br><br><br>
	
	<h3><img src="pics/blue-pageedit.png">Редактор страницы</h3>
	<div id="pageeditor">
	</div><?
}?>
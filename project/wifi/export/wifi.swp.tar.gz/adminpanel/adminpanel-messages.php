<? 
/************************************************************************************
* Snippet Name : adminpanel-checkuserrole.php										*															
* Scripted By  : RomanyukAlex		           										*														
* Website      : http://popwebstudio.ru	   											*				 
* Email        : admin@popwebstudio.ru    					 						* 
* License      : License on popwebstudio.ru from autor		 						*
* Purpose 	 : Процесс аутентификации юзера администраторского веб-интерфеса		*
* Insert		 : include_once('adminpanel-checkuserrole.php');					*  
************************************************************************************/
$log->LogInfo(basename (__FILE__)." | Got ".(__FILE__));
if($adminpanel==1){
?>
<table id="messages_table" class="settings_table">
	<tr class="gradient_to_top_1"><th width="25%">Описание сообщения</th><th width="60%">Текст</th><th width="15%">Действия</th></tr>
	<?
	# Границы выбора
	if($moduleid){#Выбирают настройки модуля
		$meswhere="`module_id`='$moduleid'";
	} else $meswhere="1";
	
	$messagesdatareq=mysql_query("SELECT * FROM `$tableprefix-messages` WHERE $meswhere order by `module_name` asc, `message_id` asc;");
	//$modulesinforeq=mysql_query("SELECT * FROM `$tableprefix-modulesregister` WHERE 1";
	while($avmodulesresult=mysql_fetch_array($avmodulesqry)){$moduledescription[$avmodulesresult['modulename']]=$avmodulesresult['module_description'];}
	if(mysql_num_rows($messagesdatareq)>0){
		while($messagesdata=mysql_fetch_array($messagesdatareq)){
			$messages_module_id=$messagesdata['module_name'];
			if($messages_module_id!==$prev_messages_module_id){ # Пошли настройки нового модуля
				$moduleinfo=mysql_fetch_array(mysql_query("SELECT * FROM `$tableprefix-modulesregister` WHERE `module_id`='$messages_module_id'"));
				//echo "ЭТО НАСТРОЙКИ МОДУЛЯ ".$moduleinfo['module_description'];
			}
			
			
				?><tr><td  class="barrel-rounded">
				<? if($moduledescription[$messages_module_id]){?>
				<b style="font-size:11px"><?=$moduledescription[$messages_module_id];?></b><br><?} 
				echo $messagesdata['message_meaning'];?></td>
				<td class="heavy-rounded"><div id='upd_message_<?=$messagesdata['message_id']?>_ap'></div>
				<form id="upd_message_form_<?=$messagesdata['message_id']?>">
				RU : <input type='text' SIZE='<?=$formsize_standart?>' MAXLENGTH="<?=$messagesdata['formmaxlegth']?>" 
				name='message_ru' value="<?=$messagesdata['message_ru']?>" 
				onFocus="showblock('mes_savebutton_<?=$messagesdata['message_id']?>');return false;" 
				id='message_ru_<?=$messagesdata['message_id']?>'><br>
				EN : <input type='text' SIZE='<?=$formsize_standart?>' MAXLENGTH="<?=$messagesdata['formmaxlegth']?>" 
				name='message_en' value="<?=$messagesdata['message_en']?>" 
				onFocus="showblock('mes_savebutton_<?=$messagesdata['message_id']?>');return false;" 
				id='message_en_<?=$messagesdata['message_id']?>'><br>
				</form>
				<?if($userrole=="root"){
						?><br>Вызов: <input value="echo $sitemessage[<?=$messagesdata['module_name']?>][<?=$messagesdata['message_code']?>];" size="<?=($formsize_standart-29)?>" readonly="readonly"><?
					}
				?></td>
				<td class="barrel-rounded">&nbsp <div id="mes_savebutton_<?=$messagesdata['message_id']?>" style="display:none"><a class="large button orange light-rounded" 
					onClick="saveform2('<?=$messagesdata['message_id']?>','upd_message_form_<?=$messagesdata['message_id']?>','upd_message_<?=$messagesdata['message_id']?>_ap','adminpanel','upd_message','','');">
					Сохранить</a><br><br></div>
				<? /*if($userrole=="root"){?><div id="accessbutton_<?=$messagesdata['message_id']?>"><a class="small button blue light-rounded" onClick="ajaxreq('<?=$messagesdata[id]?>','<? if($messagesdata['showtositeadmin']=="2"){?>admin_access_accept<?} else{?>admin_access_deny<? }?>','change_param','fieldmessage_'+paramid,'adminpanel');save_param('<?=$messagesdata[id]?>')"><? if($messagesdata['showtositeadmin']=="2"){echo "Разрешить доступ админу";}else{echo "Запретить доступ админу";}?></a></div><?} */?>
				</td>
				</tr>
	<?		$prev_messages_module_id=$messages_module_id;
		}
		if($userrole=="root"){
			?><tr><td class="barrel-rounded">
			<b style="font-size:11px">Новое сообщение</b><br>
			<input></td><td class="heavy-rounded">
		
		
			RU : <input type='text' SIZE='<?=$formsize_standart?>' 
			name='<?=$messagesdata['message_id']?>' value="" 
			onFocus="showblock('savebutton_<?=$messagesdata['message_id']?>');return false;" 
			id='field_<?=$messagesdata['message_id']?>'><br>
			EN : <input type='text' SIZE='<?=$formsize_standart?>' MAXLENGTH="<?=$messagesdata['formmaxlegth']?>" 
			name='<?=$messagesdata['message_id']?>' value="" 
			onFocus="showblock('savebutton_<?=$messagesdata['message_id']?>');return false;" 
			id='field_<?=$messagesdata['message_id']?>'><br>
			$  : <input value="" size="<?=($formsize_standart-29)?>">
	
		
			</td><td class="barrel-rounded"></td></tr><?
		}
	} else {?><tr><td class="barrel-rounded"></td><td class="heavy-rounded">Сообщения не найдены</td><td class="barrel-rounded"></td></tr><?
	}?>
</table>
<? } ?>
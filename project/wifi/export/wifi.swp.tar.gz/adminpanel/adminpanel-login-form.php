<? 
/*****************************************************************************************************************************
  * Snippet Name : adminpanel-login-form.php																				 * 
  * Scripted By  : RomanyukAlex		           																				 * 
  * Website      : http://popwebstudio.ru	   																				 * 
  * Email        : admin@popwebstudio.ru    					 														     * 
  * License      : License on popwebstudio.ru from autor		 															 *
  * Purpose 	 : Форма авторизации в администраторский Веб-кабинет									 					 *
  * Insert		 : include_once('adminpanel-login-form.php');																 *
  ***************************************************************************************************************************/ 
$log->LogInfo(basename (__FILE__)." | Got ".(__FILE__));
if ($userrole=="guest" and $adminpanel==1){?>
<script type="text/javascript" src="/js/md5.js"></script>
<script type="text/javascript">
//<![CDATA[
function encode_pass() {
  var dp = document.getElementById('dummy_password');
  var rp = document.getElementById('real_password');
  rp.value = MD5_hexhash(dp.value);
  dp.value = '';
};
//]]>
</script>
<div style="margin: 25% 25% 10% 25%">
	<div id="errormessage"><? if($errmessage) echo $errmessage;?></div>
	<table>
		<tr>
			<td style="vertical-align:middle;">
				<a href="/"><img <?
				if(file_exists($_SERVER["DOCUMENT_ROOT"]."/project/".$projectname.$adminlogofile)){
					echo "src='/project/".$projectname.$adminlogofile."'";
				} else {?>height="200px" src="/files/shoes/Shoe512_yellow.png"<? }
				?> border="0"></a>
			</td><td>
				<br>
				<FORM ACTION="/adminpanel/" METHOD="POST" id=info onsubmit="encode_pass()">
				<? if ($errmessage){echo "<span style='font:6;'>".$errmessage."</span><br>";}; ?>
				<div id="login-wrap" class="slider">
				<label for="login">Логин</label>
				<INPUT TYPE="text" NAME="login" ID="login" MAXLENGTH="20" style="height:30;">
				</div><br><br>
				<div id="password-wrap" class="slider">
				<label for="dummy">Пароль</label>
				<input type="password" name="dummy" id="dummy_password" value="" MAXLENGTH="20" style="height:30;" /><br />
				<input type="hidden" name="password" id="real_password" value="" />
				</div><br>
				<INPUT type="text" SIZE="1" MAXLENGTH="1" name="Family" class="hid">
				<INPUT type="submit" value="Войти" id="btn" name="btn">
				</FORM>
				<br>
			</td>
		</tr>
	</table>
</div>
<? } ?>
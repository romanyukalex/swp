<? 
/************************************************************************************
* Snippet Name : adminpanel-auth.php								*															
* Scripted By  : RomanyukAlex		           								*														
* Website      : http://popwebstudio.ru	   									*													* 
* Email        : admin@popwebstudio.ru    					 														* 
* License      : License on popwebstudio.ru from autor		 															*
* Purpose 	 : Процесс авторизации юзера администраторского веб-интерфеса							 					*
* Insert		 : include_once('adminpanel-auth.php');															*  ************************************************************************************/ 
$log->LogInfo(basename (__FILE__)." | Got ".(__FILE__));
if($adminpanel==1){
@require_once($_SERVER["DOCUMENT_ROOT"]."/core/db/db_class.php");
class Userauth {
    protected static $instance;  // object instance
    //private function __construct(){ /* ... @return Singleton */ }  // Защищаем от создания через new Singleton
    private function __clone()    { /* ... @return Singleton */ }  // Защищаем от создания через клонирование
    private function __wakeup()   { /* ... @return Singleton */ }  // Защищаем от создания через unserialize
    public static function getInstance() {    // Возвращает единственный экземпляр класса. @return Singleton
        if ( is_null(self::$instance) ) {
            self::$instance = new Singleton;
        }
        return self::$instance;
    }
    public function get_user_rights($userid) { //print "userid=".$userid;
		$userrightsquery=DB::query("SELECT * FROM `swp-users-admin` WHERE `userid`='$userid';");
        while($userrights=DB::fetch_object($userrightsquery)){
            return $userrights->userid;
        }
	}
	public function checkrights($table,$objectid) { print "Works\n"; }
 }
// Userauth::getInstance()->doAction(); // Применение, гарантирует наличие только одного инстанса
}
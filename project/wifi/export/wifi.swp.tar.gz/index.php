<? $base_memory_usage = memory_get_usage(); # Определяем, сколько было скушано памяти в начале
@include($_SERVER["DOCUMENT_ROOT"]."/core/start_platform_scripts.php");
# Блокировка IE6
if($showsiteforie6=="Предлагать другие браузеры" and $browser=="ie" and $browserversion=="6"){ # Предлагаем сменить браузер
	$log->LogDebug("index.php | ".(__LINE__)." | Trying to show /pages/ie6decline/index_".$language.".html");
	@include($_SERVER["DOCUMENT_ROOT"]."/pages/ie6decline/index_".$language.".html");exit();
}
if ($reconstruction_page!=="Включить" or ($reconstruction_page=="Включить" and $mode=="debug")) {# Доктайп этого проекта
	$log->LogDebug("index.php | ".(__LINE__)." | Trying to get /project/".$projectname."/templates/$sitetemplate/doctype.php");
	@include($_SERVER["DOCUMENT_ROOT"]."/project/".$projectname."/templates/$sitetemplate/doctype.php");
}
if($_REQUEST['action']=="export_code" or $_REQUEST['action']=="export_db" or $_REQUEST['action']=="delete_exported_code" or $_REQUEST['action']=="delete_exported_dump"){ # Экспортируем код платформы
	include($_SERVER["DOCUMENT_ROOT"]."/core/export_swp.php");
	$log->LogDebug("index.php | ".(__LINE__)." | Procedure $_REQUEST[action] done. Now die.");
	die();
}
?><html lang="<?=$language?>"><head><?

if($_REQUEST['action']!=="index_this") {
	$log->LogDebug("index.php |  ".(__LINE__)." |Trying to get platform_header");
	include($_SERVER["DOCUMENT_ROOT"]."/core/platform_header.php");// Стандартные js и css + meta теги
	$log->LogDebug("index.php | ".(__LINE__)." | Trying to call /project/".$projectname."templates/$sitetemplate/scripts_and_styles.php");
	include($_SERVER["DOCUMENT_ROOT"]."/project/".$projectname."/templates/$sitetemplate/scripts_and_styles.php");// Скрипты и стили проекта
}
# Перенаправление на мобильную версию, если необходимо
# Разрешено ли этому IP смотреть сайт?
if($sitecorrectipaddress!=="NO"){
	$valid_ip_address=$sitecorrectipaddress;
	$log->LogDebug("index.php | ".(__LINE__)." | Trying to call /modules/IPfilter/design.php");
	include($_SERVER["DOCUMENT_ROOT"]."/modules/IPfilter/design.php");
}
# Определяем userrole
$log->LogDebug("index.php | ".(__LINE__)." | Trying to check userrole");
require($_SERVER["DOCUMENT_ROOT"]."/core/checkuserrole.php"); //(перенести в "/core/start_platform_scripts.php")

#### Тело страницы ####
# Перенаправление на страницу сайт на реконструкции, если необходимо
if ($reconstruction_page=="Включить" and $mode!=="debug"){
	$log->LogDebug("index.php | ".(__LINE__)." | Trying to call /pages/reconstruction_page/body.php");
	include($_SERVER["DOCUMENT_ROOT"]."/pages/reconstruction_page/body.php");
	}
else { # Вызов основного тела страницы
	if($_REQUEST['action']!=="index_this") {
	$log->LogDebug("index.php | ".(__LINE__)." | Trying to call /project/".$projectname."/templates/$sitetemplate/body.php");
	include($_SERVER["DOCUMENT_ROOT"]."/project/".$projectname."/templates/$sitetemplate/body.php");
	} else {#Выдаем контент страницы, без шаблона (для индексирования)
		include($_SERVER["DOCUMENT_ROOT"]."/core/pagemanage.php");
	}
}?>
</html>
<? 
$log->LogDebug(basename (__FILE__)." | ".(__LINE__)." | MemUsage (after all) ".memoryUsage($base_memory_usage).". Memory peak was ".memory_get_peak_usage().".");
$log->LogInfo("index.php | ".(__LINE__)." | EndOfPage -------------------");?>
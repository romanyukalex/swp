<?php
 /****************************************************************
  * Snippet Name : module config 			 					 *
  * Scripted By  : RomanyukAlex		           					 *
  * Website      : http://popwebstudio.ru	   					 *
  * Email        : admin@popwebstudio.ru     					 *
  * License      : GPL (General Public License)					 *
  * Purpose 	 : some functions								 *
  * Access		 : just insert_module("modulename")			 	 *
  ***************************************************************/
if ($nitka=="1"){
	$moduletype="facebook-api";
	$module_description="API for Facebook";
	$modulename=$moduletype;
	$moduletableprefix=$tableprefix;
 }
?>
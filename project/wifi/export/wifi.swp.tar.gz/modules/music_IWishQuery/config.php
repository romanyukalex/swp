<?php
 /****************************************************************
  * Snippet Name : module config 			 					 *
  * Scripted By  : RomanyukAlex		           					 *
  * Website      : http://popwebstudio.ru	   					 *
  * Email        : admin@popwebstudio.ru     					 *
  * License      : GPL (General Public License)					 *
  * Purpose 	 : some functions								 *
  * Access		 : just insert_module("modulename")			 	 *
  ***************************************************************/
if ($nitka=="1"){
	$moduletype="music_IWishQuery";
	$module_description="Music player IWishQuery";
	$modulename=$moduletype;
	$moduletableprefix=$tableprefix;
 }
?>
<?php
 /****************************************************************
  * Snippet Name : RSS           								 * 
  * Scripted By  : RomanyukAlex		           					 * 
  * Website      : http://popwebstudio.ru	   					 * 
  * Email        : admin@popwebstudio.ru     					 * 
  * License      : GPL (General Public License)					 * 
  * Purpose 	 : RSS news										 *
  * Access		 : include									 	 *
  ***************************************************************/
//$log->LogInfo(basename (__FILE__)." | Got ".(__FILE__));
if ($nitka=="1"){  
?><link type="application/rss+xml" rel="alternate" title="RSS" href="/modules/rss/" />
<? } ?>
<?php
 /****************************************************************
  * Snippet Name : module config 			 					 *
  * Scripted By  : RomanyukAlex		           					 *
  * Website      : http://popwebstudio.ru	   					 *
  * Email        : admin@popwebstudio.ru     					 *
  * License      : GPL (General Public License)					 *
  * Purpose 	 : some functions								 *
  * Access		 : just insert_module("modulename")			 	 *
  ***************************************************************/
if ($nitka=="1"){
	$moduletype="docmailgenerator";
	$module_description="Модуль генерации писем для согласования";
	$modulename=$moduletype;
	$moduletableprefix=$tableprefix;
 }
?>
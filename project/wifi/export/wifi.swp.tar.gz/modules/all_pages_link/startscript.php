<?php
/************************************************************************************
 * Snippet Name : module start script        					 					* 
 * Scripted By  : RomanyukAlex		           					 					* 
 * Website      : http://popwebstudio.ru	   					 					* 
 * Email        : admin@popwebstudio.ru     					 					* 
 * License      : GPL (General Public License)					 					* 
 * Purpose 		: page for start this module					 					*
 * Access		: create page with pagepath=/modules/modulename/startscript.php 	*
 ***********************************************************************************/
if($nitka=="1"){
	insert_module("all_pages_link");
}
?>
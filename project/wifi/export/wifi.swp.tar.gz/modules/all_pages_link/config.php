<?php
 /****************************************************************
  * Snippet Name : module config 			 					 *
  * Scripted By  : RomanyukAlex		           					 *
  * Website      : http://popwebstudio.ru	   					 *
  * Email        : admin@popwebstudio.ru     					 *
  * License      : GPL (General Public License)					 *
  * Purpose 	 : some functions								 *
  * Access		 : just insert_module("modulename")			 	 *
  ***************************************************************/
if ($nitka=="1"){
	$moduletype="all_pages_link";
	$module_description="Страница со ссылками на все страницы сайта";
	$modulename=$moduletype;
	$moduletableprefix=$tableprefix;
 }
?>